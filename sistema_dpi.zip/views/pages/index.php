<?php

header("Location: ./login");