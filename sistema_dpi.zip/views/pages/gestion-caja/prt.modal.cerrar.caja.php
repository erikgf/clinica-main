<div class="modal fade" id="mdl-cerrarcaja"  role="dialog" aria-labelledby="mdl-cerrarcajalabel">
    <div class="modal-dialog modal-lg" role="document">
        <form class="modal-content" id="frm-cerrarcaja">
            <div class="modal-header">
                <h4 class="modal-title" id="mdl-cerrarcajalabel">Cerrar Caja</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="blk-montoscerrar">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">CANCELAR</button>  
                <button type="button" class="btn btn-info" id="btn-imprimir" >IMPRIMIR (PRELIMINAR)</button>
                <button type="button" class="btn btn-success" id="btn-guardarcerrar">CERRAR CAJA</button>
            </div>
        </form>
    </div>
</div>


