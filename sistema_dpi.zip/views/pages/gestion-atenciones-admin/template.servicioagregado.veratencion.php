
{{#.}}
    <tr>
        <td>{{nombre_servicio}} 
            {{#descripcion}}
                <br><small>{{this}}</small>
            {{/descripcion}}
        </td>
        <td class="text-right">S/ {{subtotal}}</td>
    </tr>
{{/.}}