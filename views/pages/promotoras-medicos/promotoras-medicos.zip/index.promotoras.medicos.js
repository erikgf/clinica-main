var PromotorasMedicos = function() {
    var $tblPromotoras,
        $tbbPromotoras,
        $btnActualizarPromotoras,
        $tblMedicos,
        $tbbMedicos,
        $btnActualizarMedicos,
        $tblEspecialidades,
        $tbbEspecialidades,
        $btnActualizarEspecialidades;

    var tplPromotoras, 
        tplMedicos,
        tplEspecialidades;

    this.getTemplates = function(){
        var $reqPromotoras =  $.get("template.promotoras.php"),
            $reqMedicos =  $.get("template.medicos.php"),
            $reqEspecialidades =  $.get("template.especialidades.php");
        
        $.when($reqPromotoras, $reqMedicos, $reqEspecialidades)
            .done(function(resPromotoras, resMedicos, resEspecialidades){
                tplPromotoras = Handlebars.compile(resPromotoras[0]);
                tplMedicos = Handlebars.compile(resMedicos[0]);
                tplEspecialidades = Handlebars.compile(resEspecialidades[0]);

                objEspecialidad = new Especialidad(tplEspecialidades, $tblEspecialidades, $tbbEspecialidades);
                objPromotora =  new Promotora(tplPromotoras, $tblPromotoras, $tbbPromotoras);
                objMedico = new Medico(tplMedicos, $tblMedicos, $tbbMedicos);

            })
            .fail(function(e1,e2, e3){
                console.error(e1,e2, e3);
            });
    };

    this.setDOM = function(){
        $tblPromotoras = $("#tbl-promotoras");
        $tbbPromotoras  = $("#tbd-promotoras");
        $btnActualizarPromotoras  =  $("#btn-actualizar-promotoras");
        $tblMedicos =  $("#tbl-medicos");
        $tbbMedicos =  $("#tbd-medicos");
        $btnActualizarMedicos =  $("#btn-actualizar-medicos");
        $tblEspecialidades = $("#tbl-especialidades");
        $tbbEspecialidades  = $("#tbd-especialidades");
        $btnActualizarEspecialidades =  $("#btn-actualizar-especialidades");
        
    };
    
    this.setEventos = function(){
        $btnActualizarPromotoras.on("click", function(e){
            e.preventDefault();
            objPromotora.cargar();
        });

        $btnActualizarMedicos.on("click", function(e){
            e.preventDefault();
            objMedico.cargar();
        });

        $btnActualizarEspecialidades.on("click", function(e){
            e.preventDefault();
            objEspecialidad.cargar();
        });

        $("#btn-nuevo-medicos").on("click", function(e){
            e.preventDefault();
            objMedico.nuevoRegistro();
        });

        $tbbMedicos.on("click", ".btn-editar", function (e) {
            e.preventDefault();
            objMedico.leer(this.dataset.id);
        });

        $tbbMedicos.on("click", ".btn-eliminar", function (e) {
            e.preventDefault();
            objMedico.anular(this.dataset.id);
        });

        $tbbEspecialidades.on("click", ".btn-editar", function (e) {
            e.preventDefault();
            objEspecialidad.leer(this.dataset.id);
        });

        $tbbEspecialidades.on("click", ".btn-eliminar", function (e) {
            e.preventDefault();
            objEspecialidad.anular(this.dataset.id);
        });


        $tbbPromotoras.on("click", ".btn-editar", function (e) {
            e.preventDefault();
            objPromotora.leer(this.dataset.id);
        });

        $tbbPromotoras.on("click", ".btn-eliminar", function (e) {
            e.preventDefault();
            objPromotora.anular(this.dataset.id);
        });
    };

    this.getTemplates();
    this.setDOM();
    this.setEventos();
    return this;
};

var Medico = function(_template, _$tabla, _$tbody){
    var $mdl,   
        $txtIdMedico,
        $txtNumeroDocumento,
        $txtApellidosNombres,
        $txtColegiatura,
        $txtRne,
        $txtTelefonoUno,
        $txtTelefonoDos,
        $txtCorreo,
        $txtDomicilio,
        $txtEspecialidad,
        $txtPromotora,
        $txtObservaciones,
        $btnEliminar,
        $btnGuardar;

    var tplMedicos,
        $tblMedicos,
        $tbbMedicos;
    
    this.setInit = function(){
        tplMedicos  = _template;
        $tblMedicos  = _$tabla;
        $tbbMedicos  = _$tbody;

        this.setDOM();
        this.setEventos();

        this.cargar();
        return this;
    };

    this.setDOM = function(){
        $mdl = $("#mdl-medico");
        $txtIdMedico = $("#txt-medico-seleccionado");
        $txtNumeroDocumento = $("#txt-medico-numerodocumento");
        $txtApellidosNombres = $("#txt-medico-apellidosnombres");
        $txtColegiatura = $("#txt-medico-colegiatura");
        $txtRne = $("#txt-medico-rne");
        $txtTelefonoUno = $("#txt-medico-telefonouno");
        $txtTelefonoDos = $("#txt-medico-telefonodos");
        $txtCorreo = $("#txt-medico-correo");
        $txtDomicilio = $("#txt-medico-domicilio");
        $txtEspecialidad = $("#txt-medico-especialidad");
        $txtPromotora = $("#txt-medico-promotora");
        $txtObservaciones = $("#txt-medico-observaciones");
        $btnEliminar = $("#btn-medico-eliminar");
        $btnGuardar = $("#btn-medico-guardar");
    };

    this.setEventos = function () {
        var self = this;

        $btnEliminar.on("click", function () {
            self.anular(this.dataset.id);
        });
        
        $btnGuardar.on("click", function(e){
            self.guardar();
        });

        $mdl.on("hidden.bs.modal", function(e){
            $btnEliminar.hide();
            $mdl.find("form")[0].reset();
        });
    };

    this.nuevoRegistro = function(){
        $mdl.find("form")[0].reset();
        $mdl.modal("show");
        $mdl.find(".modal-title").html("Nuevo Médico");
        $txtIdMedico.val("");
    };

    this.leer = function(id){
        var self = this;
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"medico.controlador.php?op=leer",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_medico : id
            },
            success: function(result){
                $mdl.modal("show");
                self.render(result);
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.render = function(dataMedico){
        $mdl.find(".modal-title").html("Editando Médico");

        $txtIdMedico.val(dataMedico.id_medico);
        $txtNumeroDocumento.val(dataMedico.numero_documento);
        $txtApellidosNombres.val(dataMedico.apellidos_nombres);
        $txtColegiatura.val(dataMedico.colegiatura);
        $txtRne.val(dataMedico.rne);
        $txtTelefonoUno.val(dataMedico.telefono_uno);
        $txtTelefonoDos.val(dataMedico.telefono_dos);
        $txtCorreo.val(dataMedico.correo);
        $txtDomicilio.val(dataMedico.domicilio);
        $txtEspecialidad.val(dataMedico.id_especialidad);
        $txtPromotora.val(dataMedico.id_promotora);
        $txtObservaciones.val(dataMedico.observaciones);
        
        $btnEliminar.show();
    };

    this.anular = function(idMedico){
        if (!confirm("¿Está seguro de dar de baja este médico")){
            return;
        }
        var self = this;

        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"medico.controlador.php?op=anular",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_medico : idMedico
            },
            success: function(result){
                toastr.success(result.msj);
                self.cargar();
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.guardar = function(){
        var self = this;

        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"medico.controlador.php?op=guardar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_medico : $txtIdMedico.val(),
                p_numero_documento : $txtNumeroDocumento.val(),
                p_apellidos_nombres : $txtApellidosNombres.val(),
                p_colegiatura : $txtColegiatura.val(),
                p_rne : $txtRne.val(),
                p_telefono_uno : $txtTelefonoUno.val(),
                p_telefono_dos : $txtTelefonoDos.val(),
                p_correo : $txtCorreo.val(),
                p_domicilio : $txtDomicilio.val(),
                p_id_especialidad : $txtEspecialidad.val(),
                p_id_promotora : $txtPromotora.val(),
                p_observaciones : $txtObservaciones.val()
            },
            success: function(result){
                toastr.success(result.msj);
                self.cargar();
                
                $mdl.modal("hide");
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    TABLA_MEDICOS  = null;
    this.cargar = function(){
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"medico.controlador.php?op=listar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {},
            success: function(result){
                if (TABLA_MEDICOS){
                    TABLA_MEDICOS.destroy();
                }

                $tbbMedicos.html(tplMedicos(result));
                TABLA_MEDICOS = $tblMedicos.DataTable({
                    "ordering": false
                });
                
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    return this.setInit();
};

var Especialidad = function(_template, _$tabla, _$tbody){
    var $mdl,   
        $txtIdEspecialidad,
        $txtDescripcion,
        $btnEliminar,
        $btnGuardar;

    var tplEspecialidades,
        $tblEspecialidades,
        $tbbEspecialidades;
    
    this.setInit = function(){
        tplEspecialidades  = _template;
        $tblEspecialidades  = _$tabla;
        $tbbEspecialidades  = _$tbody;

        this.setDOM();
        this.setEventos();

        this.cargar();
        return this;
    };

    this.setDOM = function(){
        $mdl = $("#mdl-especialidad");
        $txtIdEspecialidad = $("#txt-especialidad-seleccionado");
        $txtDescripcion = $("#txt-especialidad-descripcion");
        $btnEliminar = $("#btn-especialidad-eliminar");
        $btnGuardar = $("#btn-especialidad-guardar");
    };

    this.setEventos = function () {
        var self = this;

        $btnEliminar.on("click", function () {
            self.anular(this.dataset.id);
        });
        
        $btnGuardar.on("click", function(e){
            self.guardar();
        });

        $mdl.on("hidden.bs.modal", function(e){
            $btnEliminar.hide();
            $mdl.find("form")[0].reset();
        });

        
    };

    this.nuevoRegistro = function(){
        $mdl.find("form")[0].reset();
        $mdl.modal("show");
        $mdl.find(".modal-title").html("Nueva Especialidad");
        $txtIdEspecialidad.val("");
    };

    this.leer = function(id){
        var self = this;
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"especialidad.controlador.php?op=leer",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_especialidad : id
            },
            success: function(result){
                $mdl.modal("show");
                self.render(result);
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.render = function(data){
        $mdl.find(".modal-title").html("Editando Especialidad");

        $txtIdEspecialidad.val(data.id_especialidad);
        $txtDescripcion.val(data.descripcion);
        
        $btnEliminar.show();
    };

    this.anular = function(id){
        var self = this;

        if (!confirm("¿Está seguro de dar de baja esta especialidad")){
            return;
        }

        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"especialidad.controlador.php?op=anular",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_especialidad : id
            },
            success: function(result){
                toastr.success(result.msj);
                self.cargar();
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.guardar = function(){
        var self = this;
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"especialidad.controlador.php?op=guardar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_especialidad_medico : $txtIdEspecialidad.val(),
                p_descripcion : $txtNumeroDocumento.val()
            },
            success: function(result){
                toastr.success(result.msj);
                self.cargar();
                
                $mdl.modal("hide");
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.cargar = function(){
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"especialidad.controlador.php?op=listar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {},
            success: function(result){
                $tbbEspecialidades.html(tplEspecialidades(result));

                var $html = ``;
                result.forEach(especialidad => {
                    $html += `<option value="${especialidad.id}">${especialidad.descripcion}</option>`;
                });
                $("#txt-medico-especialidad").html($html);
                
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    return this.setInit();
};

var Promotora = function(_template, _$tabla, _$tbody){
    var $mdl,   
        $txtIdPromotora,
        $txtDescripcion,
        $txtComision,
        $btnEliminar,
        $btnGuardar;

    var tplPromotoras,
        $tblPromotoras,
        $tbbPromotoras;
    
    this.setInit = function(){
        tplPromotoras  = _template;
        $tblPromotoras  = _$tabla;
        $tbbPromotoras  = _$tbody;

        this.setDOM();
        this.setEventos();

        this.cargar();
        return this;
    };

    this.setDOM = function(){
        $mdl = $("#mdl-promotora");
        $txtIdPromotora = $("#txt-promotora-seleccionado");
        $txtDescripcion = $("#txt-promotora-descripcion");
        $txtDescripcion = $("#txt-promotora-comision");
        $btnEliminar = $("#btn-promotora-eliminar");
        $btnGuardar = $("#btn-promotora-guardar");
    };

    this.setEventos = function () {
        var self = this;

        $btnEliminar.on("click", function () {
            self.anular(this.dataset.id);
        });
        
        $btnGuardar.on("click", function(e){
            self.guardar();
        });

        $mdl.on("hidden.bs.modal", function(e){
            $btnEliminar.hide();
            $mdl.find("form")[0].reset();
        });
    };

    this.nuevoRegistro = function(){
        $mdl.find("form")[0].reset();
        $mdl.modal("show");
        $mdl.find(".modal-title").html("Nueva Promotora");

        $txtIdPromotora.val("");
    };

    this.leer = function(id){
        var self = this;
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"promotora.controlador.php?op=leer",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_promotora : id
            },
            success: function(result){
                $mdl.modal("show");
                self.render(result);
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.render = function(data){
        $mdl.find(".modal-title").html("Editando Promotora");

        $txtIdPromotora.val(data.id_promotora);
        $txtDescripcion.val(data.descripcion);
        $txtComision.val(data.comision_promotora);
        
        $btnEliminar.show();
    };

    this.anular = function(id){
        var self = this;

        if (!confirm("¿Está seguro de dar de baja esta promotora")){
            return;
        }

        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"promotora.controlador.php?op=anular",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_promotora : id
            },
            success: function(result){
                toastr.success(result.msj);
                self.cargar();
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.guardar = function(){
        var self = this;
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"promotora.controlador.php?op=guardar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {
                p_id_promotora : $txtIdPromotora.val(),
                p_descripcion : $txtDescripcion.val(),
                p_comision : $txtComision.val()
            },
            success: function(result){

                console.log(result);
                return; 
                toastr.success(result.msj);
                self.cargar();
                
                $mdl.modal("hide");
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    this.cargar = function(){
        $.ajax({ 
            url : VARS.URL_CONTROLADOR+"promotora.controlador.php?op=listar",
            type: "POST",
            dataType: 'json',
            delay: 250,
            data: {},
            success: function(result){
                $tbbPromotoras.html(tplPromotoras(result));

                var $html = `<option value="">Sin Promotora</option>`;
                result.forEach(promotora => {
                    $html += `<option value="${promotora.id}">${promotora.descripcion}</option>`;
                });
                $("#txt-medico-promotora").html($html);
                
            },
            error: function (request) {
                toastr.error(request.responseText);
                return;
            },
            cache: true
            }
        );
    };

    return this.setInit();
};

$(document).ready(function(){
    objPromotorasMedicos = new PromotorasMedicos();
});


