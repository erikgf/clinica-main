{{#.}}
    <tr data-id="{{id}}">
        <td>{{text}}</td>
        <td>{{telefonos}}</td>
    </tr>
{{else}}
    <tr>
        <td colspan="12" class="text-center"><i>Sin datos que mostrar</i></td>
    </tr>
{{/.}}